import { practice as control } from '../control/src/run.ts'
import { practice as coverage } from '../coverage/src/run.ts'
export async function practice(client: Parameters<typeof control>[0], options: Parameters<typeof control>[1] & {settings: Record<string, unknown>}) {
  const {privateCoverage, ...settings} = options.settings
  if (typeof privateCoverage !== 'boolean' || options.board) throw new Error('Explicit unranked arm required')
  return privateCoverage ? coverage(client as unknown as Parameters<typeof coverage>[0], {...options, settings: {...settings, privateCoverage: true}}) : control(client, {...options, settings})
}
