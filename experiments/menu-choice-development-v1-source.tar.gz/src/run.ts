import { practice as control } from '../control/src/run.ts'
import { practice as menu } from '../menu/src/run.ts'
export async function practice(client: Parameters<typeof control>[0], options: Parameters<typeof control>[1] & {settings: Record<string, unknown>}) {
  const {menuChoice, ...settings} = options.settings
  if (typeof menuChoice !== 'boolean' || options.board) throw new Error('Explicit unranked menu-study arm required')
  return menuChoice ? menu(client as unknown as Parameters<typeof menu>[0], {...options, settings: {...settings, menuChoice: true}}) : control(client, {...options, settings})
}
